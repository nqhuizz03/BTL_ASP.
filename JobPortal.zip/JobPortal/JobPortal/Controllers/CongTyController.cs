﻿using JobPortal.Models;
using JobPortal.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System.Threading.Tasks;

namespace JobPortal.Controllers
{
    [Authorize(Roles = "Admin,CongTy")]
    public class CongTyController : Controller
    {
        private readonly ICongTyService _congTyService;

        public CongTyController(ICongTyService congTyService)
        {
            _congTyService = congTyService;
        }

        [AllowAnonymous]
        public async Task<IActionResult> Index()
        {
            var companies = await _congTyService.GetAll();
            return View(companies);
        }

        [AllowAnonymous]
        public async Task<IActionResult> Details(int id)
        {
            var congTy = await _congTyService.GetById(id);
            if (congTy == null)
            {
                return NotFound();
            }
            return View(congTy);
        }

        [Authorize(Roles = "Admin")]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Create([Bind("Id,TenCongTy,DiaChi,DienThoai,Email")] CongTy congTy)
        {
            if (ModelState.IsValid)
            {
                await _congTyService.Create(congTy);
                return RedirectToAction(nameof(Index));
            }
            return View(congTy);
        }

        [Authorize(Roles = "Admin,CongTy")]
        public async Task<IActionResult> Edit(int id)
        {
            var congTy = await _congTyService.GetById(id);
            if (congTy == null)
            {
                return NotFound();
            }
            return View(congTy);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin,CongTy")]
        public async Task<IActionResult> Edit(int id, [Bind("Id,TenCongTy,DiaChi,DienThoai,Email")] CongTy congTy)
        {
            if (id != congTy.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                await _congTyService.Update(congTy);
                return RedirectToAction(nameof(Index));
            }
            return View(congTy);
        }

        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int id)
        {
            var congTy = await _congTyService.GetById(id);
            if (congTy == null)
            {
                return NotFound();
            }
            return View(congTy);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            await _congTyService.Delete(id);
            return RedirectToAction(nameof(Index));
        }
    }
}