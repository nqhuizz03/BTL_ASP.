﻿using JobPortal.Services;
using Microsoft.AspNetCore.Mvc;

namespace JobPortal.Controllers
{
    public class HomeController : Controller
    {
        private readonly IViecLamService _viecLamService;

        public HomeController(IViecLamService viecLamService)
        {
            _viecLamService = viecLamService;
        }

        public async Task<IActionResult> Index(string searchString)
        {
            var viecLams = await _viecLamService.GetAll();

            if (!string.IsNullOrEmpty(searchString))
            {
                viecLams = await _viecLamService.Search(searchString);
            }

            return View(viecLams);
        }

        public IActionResult Privacy()
        {
            return View();
        }
    }
}