﻿using JobPortal.Models;
using JobPortal.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace JobPortal.Controllers
{
    [Authorize]
    public class ViecLamController : Controller
    {
        private readonly IViecLamService _viecLamService;
        private readonly ICongTyService _congTyService;

        public ViecLamController(IViecLamService viecLamService, ICongTyService congTyService)
        {
            _viecLamService = viecLamService;
            _congTyService = congTyService;
        }

        [AllowAnonymous]
        public async Task<IActionResult> Index(string searchString)
        {
            var viecLams = await _viecLamService.GetAll();

            if (!string.IsNullOrEmpty(searchString))
            {
                viecLams = await _viecLamService.Search(searchString);
            }

            return View(viecLams);
        }

        [AllowAnonymous]
        public async Task<IActionResult> Details(int id)
        {
            var viecLam = await _viecLamService.GetById(id);
            if (viecLam == null)
            {
                return NotFound();
            }
            return View(viecLam);
        }

        [Authorize(Roles = "Admin,CongTy")]
        public async Task<IActionResult> Create()
        {
            ViewBag.CongTys = await _congTyService.GetAll();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin,CongTy")]
        public async Task<IActionResult> Create(ViecLam viecLam)
        {
            if (ModelState.IsValid)
            {
                await _viecLamService.Create(viecLam);
                return RedirectToAction(nameof(Index));
            }
            ViewBag.CongTys = await _congTyService.GetAll();
            return View(viecLam);
        }

        [Authorize(Roles = "Admin,CongTy")]
        public async Task<IActionResult> Edit(int id)
        {
            var viecLam = await _viecLamService.GetById(id);
            if (viecLam == null)
            {
                return NotFound();
            }
            ViewBag.CongTys = await _congTyService.GetAll();
            return View(viecLam);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin,CongTy")]
        public async Task<IActionResult> Edit(int id, ViecLam viecLam)
        {
            if (id != viecLam.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                await _viecLamService.Update(viecLam);
                return RedirectToAction(nameof(Index));
            }
            ViewBag.CongTys = await _congTyService.GetAll();
            return View(viecLam);
        }

        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int id)
        {
            var viecLam = await _viecLamService.GetById(id);
            if (viecLam == null)
            {
                return NotFound();
            }
            return View(viecLam);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            await _viecLamService.Delete(id);
            return RedirectToAction(nameof(Index));
        }
    }
}