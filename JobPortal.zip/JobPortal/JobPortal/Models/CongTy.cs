﻿using System.ComponentModel.DataAnnotations;

namespace JobPortal.Models
{
    public class CongTy
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Tên công ty không được để trống")]
        [StringLength(200, ErrorMessage = "Tên công ty không quá 200 ký tự")]
        public string TenCongTy { get; set; }

        public string MaSoThue { get; set; }
        public string DiaChi { get; set; }
        public string DienThoai { get; set; }
        public string Website { get; set; }
        public string LogoUrl { get; set; }

        public int UserId { get; set; }
        public NguoiDung User { get; set; }

        public ICollection<ViecLam> Vieclams { get; set; }
    }
}