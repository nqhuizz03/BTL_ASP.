﻿namespace JobPortal.Models
{
    public class EmailSettings
    {
        public string SmtpServer { get; set; }
        public int SmtpPort { get; set; }
        public string SmtpUsername { get; set; }
        public string SmtpPassword { get; set; }
        public string FromName { get; set; }
        public string FromAddress { get; set; }

        // Cấu hình template email
        public string ConfirmEmailTemplate { get; set; }
        public string ResetPasswordTemplate { get; set; }
        public string JobApplicationTemplate { get; set; }
    }
}