﻿using System;
using System.ComponentModel.DataAnnotations;

namespace JobPortal.Models
{
    public class HoSoUngTuyen
    {
        public int Id { get; set; }

        [Required]
        public int ViecLamId { get; set; }
        public ViecLam ViecLam { get; set; }

        [Required]
        public int NguoiDungId { get; set; }
        public NguoiDung NguoiDung { get; set; }

        [Required]
        public string CVUrl { get; set; }

        public DateTime NgayNop { get; set; } = DateTime.Now;

        [StringLength(50)]
        public string TrangThai { get; set; } = "Đã nộp";

        public string GhiChu { get; set; }
    }
}