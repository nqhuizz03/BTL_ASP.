﻿using Microsoft.EntityFrameworkCore;
using JobPortal.Models;

namespace JobPortal.Data
{
    public class JobPortalDbContext : DbContext
    {
        public JobPortalDbContext(DbContextOptions<JobPortalDbContext> options)
            : base(options)
        {
        }

        public DbSet<ViecLam> Vieclams { get; set; }
        public DbSet<CongTy> CongTies { get; set; }
        public DbSet<NguoiDung> NguoiDungs { get; set; }
        public DbSet<HoSoUngTuyen> HoSoUngTuyens { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<HoSoUngTuyen>()
                .HasOne(h => h.ViecLam)
                .WithMany(v => v.HoSoUngTuyens)
                .HasForeignKey(h => h.ViecLamId);

            modelBuilder.Entity<HoSoUngTuyen>()
                .HasOne(h => h.NguoiDung)
                .WithMany(u => u.HoSoUngTuyens)
                .HasForeignKey(h => h.NguoiDungId);

            modelBuilder.Entity<ViecLam>()
                .HasOne(v => v.CongTy)
                .WithMany(c => c.Vieclams)
                .HasForeignKey(v => v.CongTyId);

            modelBuilder.Entity<CongTy>()
                .HasOne(c => c.User)
                .WithMany(u => u.CongTies)
                .HasForeignKey(c => c.UserId);
        }
    }
}