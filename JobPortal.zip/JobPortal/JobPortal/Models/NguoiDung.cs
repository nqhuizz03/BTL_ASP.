﻿using System.ComponentModel.DataAnnotations;

namespace JobPortal.Models
{
    public class NguoiDung
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Họ tên không được để trống")]
        public string HoTen { get; set; }

        [Required(ErrorMessage = "Email không được để trống")]
        [EmailAddress(ErrorMessage = "Email không hợp lệ")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Mật khẩu không được để trống")]
        public string MatKhauHash { get; set; }

        public string DiaChi { get; set; }
        public string SoDienThoai { get; set; }
        public DateTime NgayTao { get; set; } = DateTime.Now;
        public int TrangThai { get; set; } = 1;
        public string VaiTro { get; set; } = "User";

        public ICollection<CongTy> CongTies { get; set; }
        public ICollection<HoSoUngTuyen> HoSoUngTuyens { get; set; }
    }
}