﻿using System.ComponentModel.DataAnnotations;

namespace JobPortal.Models
{
    public class QuenMatKhauModel
    {
        [Required(ErrorMessage = "Email là bắt buộc")]
        [EmailAddress(ErrorMessage = "Email không hợp lệ")]
        [Display(Name = "Email đăng ký")]
        public string Email { get; set; }
    }

    public class DatLaiMatKhauModel
    {
        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Mật khẩu mới")]
        public string MatKhauMoi { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Xác nhận mật khẩu")]
        [Compare("MatKhauMoi", ErrorMessage = "Mật khẩu không khớp.")]
        public string XacNhanMatKhau { get; set; }

        public string Code { get; set; }
    }
}