﻿using System.ComponentModel.DataAnnotations;

namespace JobPortal.Models
{
    public class ViecLam
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Tiêu đề không được để trống")]
        [StringLength(200, ErrorMessage = "Tiêu đề không quá 200 ký tự")]
        public string TieuDe { get; set; }

        [Required(ErrorMessage = "Mô tả không được để trống")]
        public string MoTa { get; set; }

        public string YeuCau { get; set; }
        public string DiaDiem { get; set; }
        public string MucLuong { get; set; }
        public DateTime NgayTao { get; set; } = DateTime.Now;
        public DateTime? NgayHetHan { get; set; }
        public int TrangThai { get; set; } = 1;

        public int CongTyId { get; set; }
        public CongTy CongTy { get; set; }

        public ICollection<HoSoUngTuyen> HoSoUngTuyens { get; set; }
    }
}