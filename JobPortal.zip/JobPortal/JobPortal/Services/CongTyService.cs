﻿using JobPortal.Data;
using JobPortal.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JobPortal.Services
{
    public class CongTyService : ICongTyService
    {
        private readonly JobPortalContext _context;

        public CongTyService(JobPortalContext context)
        {
            _context = context;
        }

        public async Task<List<CongTy>> GetAll()
        {
            return await _context.CongTies
                .Include(c => c.User)
                .ToListAsync();
        }

        public async Task<CongTy> GetById(int id)
        {
            return await _context.CongTies
                .Include(c => c.User)
                .Include(c => c.Vieclams)
                .FirstOrDefaultAsync(c => c.Id == id);
        }

        public async Task Create(CongTy congTy)
        {
            _context.Add(congTy);
            await _context.SaveChangesAsync();
        }

        public async Task Update(CongTy congTy)
        {
            _context.Update(congTy);
            await _context.SaveChangesAsync();
        }

        public async Task Delete(int id)
        {
            var congTy = await GetById(id);
            if (congTy != null)
            {
                _context.CongTies.Remove(congTy);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<bool> CompanyExists(int id)
        {
            return await _context.CongTies.AnyAsync(e => e.Id == id);
        }
    }
}