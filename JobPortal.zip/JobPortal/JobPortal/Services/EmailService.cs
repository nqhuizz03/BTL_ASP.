﻿using MailKit.Net.Smtp;
using MailKit.Security;
using Microsoft.Extensions.Configuration;
using MimeKit;
using System.Threading.Tasks;

namespace JobPortal.Services
{
    public class EmailService : IEmailService
    {
        private readonly IConfiguration _configuration;

        public EmailService(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public async Task SendEmailAsync(string email, string subject, string message)
        {
            var emailMessage = new MimeMessage();
            emailMessage.From.Add(new MailboxAddress("Job Portal", _configuration["EmailSettings:SenderEmail"]));
            emailMessage.To.Add(new MailboxAddress("", email));
            emailMessage.Subject = subject;
            emailMessage.Body = new TextPart("html") { Text = message };

            using (var smtp = new SmtpClient())
            {
                await smtp.ConnectAsync(
                    _configuration["EmailSettings:MailServer"],
                    int.Parse(_configuration["EmailSettings:MailPort"]),
                    SecureSocketOptions.StartTls);

                await smtp.AuthenticateAsync(
                    _configuration["EmailSettings:SenderEmail"],
                    _configuration["EmailSettings:Password"]);

                await smtp.SendAsync(emailMessage);
                await smtp.DisconnectAsync(true);
            }
        }

        // ✅ Gửi email xác nhận tài khoản
        public async Task SendConfirmationEmailAsync(string email, string callbackUrl)
        {
            string subject = "Xác nhận tài khoản của bạn";
            string message = $"Vui lòng nhấp vào liên kết sau để xác nhận tài khoản: <a href='{callbackUrl}'>Xác nhận tài khoản</a>";

            await SendEmailAsync(email, subject, message);
        }

        // ✅ Gửi email đặt lại mật khẩu
        public async Task SendPasswordResetEmailAsync(string email, string callbackUrl)
        {
            string subject = "Đặt lại mật khẩu";
            string message = $"Bấm vào link sau để đặt lại mật khẩu: <a href='{callbackUrl}'>Đặt lại mật khẩu</a>";

            await SendEmailAsync(email, subject, message);
        }
    }
}
