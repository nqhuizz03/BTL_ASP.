﻿using JobPortal.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace JobPortal.Services
{
    public interface ICongTyService
    {
        Task<List<CongTy>> GetAll();
        Task<CongTy> GetById(int id);
        Task Create(CongTy congTy);
        Task Update(CongTy congTy);
        Task Delete(int id);
        Task<bool> CompanyExists(int id);
    }
}