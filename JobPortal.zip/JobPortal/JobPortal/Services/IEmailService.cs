﻿using System.Threading.Tasks;

namespace JobPortal.Services
{
    public interface IEmailService
    {
        Task SendEmailAsync(string email, string subject, string message);
        Task SendConfirmationEmailAsync(string email, string callbackUrl);
        Task SendPasswordResetEmailAsync(string email, string callbackUrl);
    }
}