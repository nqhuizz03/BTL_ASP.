﻿using JobPortal.Models;
using System.Threading.Tasks;

namespace JobPortal.Services
{
    public interface ITaiKhoanService
    {
        Task<NguoiDung> DangNhap(string email, string matKhau);
        Task<bool> DangKy(DangKyModel model);
    }
}