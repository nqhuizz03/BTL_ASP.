﻿using JobPortal.Models;

public interface IViecLamService
{
    Task<IEnumerable<ViecLam>> GetAllAsync();
    Task<ViecLam> GetByIdAsync(int id);
    Task CreateAsync(ViecLam viecLam);
    Task UpdateAsync(ViecLam viecLam);
    Task SoftDeleteAsync(int id);
    Task<IEnumerable<ViecLam>> SearchAsync(string keyword);
    Task<IEnumerable<ViecLam>> GetByCompanyIdAsync(int companyId);
    Task<int> CountActiveJobsAsync();
}