﻿using JobPortal.Data;
using JobPortal.Models;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace JobPortal.Services
{
    public class TaiKhoanService : ITaiKhoanService
    {
        private readonly JobPortalContext _context;

        public TaiKhoanService(JobPortalContext context)
        {
            _context = context;
        }

        public async Task<NguoiDung> DangNhap(string email, string matKhau)
        {
            return await _context.NguoiDungs
                .FirstOrDefaultAsync(u => u.Email == email && u.MatKhauHash == matKhau);
        }

        public async Task<bool> DangKy(DangKyModel model)
        {
            if (await _context.NguoiDungs.AnyAsync(u => u.Email == model.Email))
            {
                return false;
            }

            var user = new NguoiDung
            {
                HoTen = model.HoTen,
                Email = model.Email,
                MatKhauHash = model.MatKhau,
                VaiTro = "User"
            };

            _context.NguoiDungs.Add(user);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}