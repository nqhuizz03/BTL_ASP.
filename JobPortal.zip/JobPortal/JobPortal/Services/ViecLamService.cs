﻿using JobPortal.Data;
using JobPortal.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JobPortal.Services
{
    public class ViecLamService : IViecLamService
    {
        private readonly JobPortalContext _context;

        public ViecLamService(JobPortalContext context)
        {
            _context = context;
        }

        public async Task<List<ViecLam>> GetAll()
        {
            return await _context.Vieclams
                .Include(v => v.CongTy)
                .ToListAsync();
        }

        public async Task<ViecLam> GetById(int id)
        {
            return await _context.Vieclams
                .Include(v => v.CongTy)
                .FirstOrDefaultAsync(v => v.Id == id);
        }

        public async Task Create(ViecLam viecLam)
        {
            _context.Add(viecLam);
            await _context.SaveChangesAsync();
        }

        public async Task Update(ViecLam viecLam)
        {
            _context.Update(viecLam);
            await _context.SaveChangesAsync();
        }

        public async Task Delete(int id)
        {
            var viecLam = await GetById(id);
            if (viecLam != null)
            {
                _context.Vieclams.Remove(viecLam);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<List<ViecLam>> Search(string keyword)
        {
            return await _context.Vieclams
                .Where(v => v.TieuDe.Contains(keyword) || v.MoTa.Contains(keyword))
                .ToListAsync();
        }
    }
}